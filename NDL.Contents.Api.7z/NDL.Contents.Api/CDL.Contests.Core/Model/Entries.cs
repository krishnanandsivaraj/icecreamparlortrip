using System;

namespace NDL.Contests.Core.Model
{
  public class Entries
    {
    public int Id { get; set; }

    public string Name { get; set; }

    public string Email { get; set; }

    public DateTime Date_Participated { get; set; }

    public int Count { get; set; }
  }
}
