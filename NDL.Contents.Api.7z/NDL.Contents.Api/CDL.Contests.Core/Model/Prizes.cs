using System;

namespace NDL.Contests.Core.Model
{
  public class Prizes
  {
    public int PId { get; set; }
    public string PriceItemName { get; set; }
    public DateTime DateUnlocked { get; set; }
  }
}
