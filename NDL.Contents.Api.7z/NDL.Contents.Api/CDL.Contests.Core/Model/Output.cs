using System;

namespace NDL.Contests.Core.Model
{
  public class Output
  {
    public int Id { get; set; }
    public int PId { get; set; }
    public string PriceItemName { get; set; }
    public DateTime Date_Unlocked { get; set; }
    public string Name { get; set; }

    public string Email { get; set; }

    public DateTime Date_Participated { get; set; }

    public int Count { get; set; }
  }
}
