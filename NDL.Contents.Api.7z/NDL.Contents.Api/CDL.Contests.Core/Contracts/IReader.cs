using System;
using System.Collections.Generic;
using System.Text;

namespace NDL.Contests.Core.Contracts
{
    public interface IReader<T>
    {
      List<T> Read(string Path);
    }
}
