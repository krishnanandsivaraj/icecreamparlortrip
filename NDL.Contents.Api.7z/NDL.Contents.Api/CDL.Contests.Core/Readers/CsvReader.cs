using NDL.Contests.Core.Contracts;
using NDL.Contests.Core.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NDL.Contests.Core.Readers
{
  public class CsvReader<T> : IReader<T>
  {
    
    public List<T> Read(string path)
    {
      var input = new List<T>();
      var entries = new Entries();
      try
      {
        using (StreamReader r = new StreamReader(Convert.ToString(path)))
        {
          string line;
          //skip first line for header
          r.ReadLine();

          while ((line = r.ReadLine()) != null)
          {
            var splitLine = line.Split(",");

            switch (Convert.ToString(typeof(T)))
            {

              case "NDL.Contests.Core.Model.Entries":
                {
                  input.Add((T)Convert.ChangeType(
                new Entries { Id = Convert.ToInt32(splitLine[0]), Name = splitLine[1], Email = splitLine[2], Date_Participated = Convert.ToDateTime(splitLine[3]) },
                typeof(T)));
                  break;
                }
              case "NDL.Contests.Core.Model.Prizes":
                {
                  input.Add((T)Convert.ChangeType(
                new Prizes { PId = Convert.ToInt32(splitLine[0]), PriceItemName = splitLine[1], DateUnlocked = Convert.ToDateTime(splitLine[2]) },
                typeof(T)));
                  break;
                }
              default:
                {
                  throw new Exception("Unexpected Type Detected!!");
                }
            }
          }

      }
        }
      catch (Exception Ex)
      {
        throw new Exception("There is an error reading the file. Check FilePath or your input!!",Ex);
      }
      
      return input;
    }

  }
}
