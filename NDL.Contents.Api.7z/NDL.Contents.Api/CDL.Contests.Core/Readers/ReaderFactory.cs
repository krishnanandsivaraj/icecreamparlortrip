using NDL.Contests.Core.Contracts;
using NDL.Contests.Core.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace NDL.Contests.Core.Readers
{
  public class ReaderFactory<T>
  {
    public static IReader<T> Get(string type)
    {
      IReader<T> reader = null;
      switch (type)
      {
        case "csv":
          reader = new CsvReader<T>();
          break;
        default:
          break;
      }
      return reader;
    }
  }
}
