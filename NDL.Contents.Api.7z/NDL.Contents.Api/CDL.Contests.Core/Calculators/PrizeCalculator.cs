using NDL.Contests.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NDL.Contests.Core.Calculators
{
  public static class PrizeCalculator
  {


    public static List<Entries> GetEntriesWithCount(List<Entries> entries)
    {
      List<Entries> countDuplicates = new List<Entries>();
      
      foreach (var entry in entries.GroupBy(x => x.Name))
      {
        countDuplicates.Add(new Entries
        {
          Name = entry.Key,
          Count = entry.Count()
        });
      }

      return entries.Join(countDuplicates, ent => ent.Name, dup => dup.Name, (ent, dup) => new Entries { Name = ent.Name, Id = ent.Id, Email = ent.Email, Date_Participated = ent.Date_Participated, Count = dup.Count }).OrderByDescending(x => x.Count).ToList();

    }
  }
}
