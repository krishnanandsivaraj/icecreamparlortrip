using System;
using System.Collections.Generic;
using NDL.Contests.Core;
using NDL.Contests.Core.Readers;
using NDL.Contests.Core.Model;
using System.Linq;

namespace TestApp
{
  class Program
  {
    static void Main(string[] args)
    {

      var entriesPath = @"..\Data\entries.csv";
      var prizesPath = @"..\Data\prizes.csv";
      List<Output> output = new List<Output>();
      List<Entries> entries = ReaderFactory<Entries>.Get(@"csv").Read(entriesPath);
      
      List<Prizes> prizes = ReaderFactory<Prizes>.Get(@"csv").Read(prizesPath);

      List<Entries> countDuplicates = new List<Entries>();

      //prize.Date_Unlocked.Date, prize.Date_Unlocked.TimeOfDay

      foreach (var entry in entries.GroupBy(x => x.Name))
      { 
        countDuplicates.Add(new Entries { Name = entry.Key, Count = entry.Count() });
      }

      entries = entries.Join(countDuplicates, ent => ent.Name, dup => dup.Name, (ent, dup) => new Entries { Name=ent.Name,Id=ent.Id, Email=ent.Email, Date_Participated=ent.Date_Participated, Count=dup.Count}).OrderByDescending(x=>x.Count).ToList();
      output = entries.Join(prizes, ent => ent.Date_Participated, priz => priz.DateUnlocked, (entry, prize) => new Output { Name= entry.Name, Email= entry.Email, Date_Participated= entry.Date_Participated, PriceItemName= prize.PriceItemName,  Date_Unlocked= prize.DateUnlocked,Id=entry.Id, PId=prize.PId, Count=entry.Count }).ToList();

      //List<Output> avoidDuplicates = output.OrderByDescending(g=>g.Count).GroupBy(x=>x.Name).Select(x=>x.First()).ToList();

      output = output.OrderByDescending(g => g.Count).GroupBy(x => x.PriceItemName).Select(x => x.First()).ToList();


      foreach (var outer in output)
      {
        entries.RemoveAll(x => x.Id == outer.Id);
        prizes.RemoveAll(x => x.PId == outer.PId);
      }

      var output2 = entries.Join(prizes, ent => ent.Date_Participated.Date, priz => priz.DateUnlocked.Date, (entry, prize) => new Output { Name = entry.Name, Email = entry.Email, Date_Participated = entry.Date_Participated, PriceItemName = prize.PriceItemName, Date_Unlocked = prize.DateUnlocked, Id = entry.Id, PId = prize.PId }).OrderBy(x => x.PriceItemName).Where(x => x.Date_Participated.TimeOfDay >= x.Date_Unlocked.TimeOfDay).Distinct().OrderBy(x => x.Date_Participated.TimeOfDay).GroupBy(x => x.PriceItemName).Select(x => x.First()).Distinct().GroupBy(x => x.Name).Select(y => y.First()).ToList();
      
      foreach (var outer in output2)
      {
        entries.RemoveAll(x => x.Id == outer.Id);
        prizes.RemoveAll(x => x.PId == outer.PId);
      }

      var output4 = entries.Join(prizes, ent => ent.Date_Participated.Date, priz => priz.DateUnlocked.Date, (entry, prize) => new Output { Name = entry.Name, Email = entry.Email, Date_Participated = entry.Date_Participated, PriceItemName = prize.PriceItemName, Date_Unlocked = prize.DateUnlocked, Id = entry.Id, PId = prize.PId }).OrderBy(x => x.PriceItemName).Where(x => x.Date_Participated.TimeOfDay >= x.Date_Unlocked.TimeOfDay).Distinct().OrderBy(x => x.Date_Participated.TimeOfDay).GroupBy(x => x.PriceItemName).Select(x => x.First()).Distinct().ToList();

      foreach (var outer in output4)
      {
        entries.RemoveAll(x => x.Id == outer.Id);
        prizes.RemoveAll(x => x.PId == outer.PId);
      }

      

      var output5 = entries.Join(prizes, ent => ent.Date_Participated.Date, priz => priz.DateUnlocked.Date, (entry, prize) => new Output { Name = entry.Name, Email = entry.Email, Date_Participated = entry.Date_Participated, PriceItemName = prize.PriceItemName, Date_Unlocked = prize.DateUnlocked, Id = entry.Id, PId = prize.PId }).OrderBy(x => x.PriceItemName).Where(x => x.Date_Participated.TimeOfDay >= x.Date_Unlocked.TimeOfDay).Distinct().OrderBy(x => x.Date_Participated.TimeOfDay).GroupBy(x => x.PriceItemName).Select(x => x.First()).Distinct().ToList();


      List<Output> output6 = new List<Output>();
      if (output5.Count == 0) {
        foreach (var s in prizes.OrderByDescending(x=>x.DateUnlocked)) {
          Entries op = entries.FirstOrDefault(x => x.Date_Participated.Date > s.DateUnlocked.Date);
          if (op != null) { 
          output6.Add(new Output { Id = op.Id, Name = op.Name, Email = op.Email, Date_Participated = op.Date_Participated, Count = op.Count, PId = s.PId, Date_Unlocked = s.DateUnlocked, PriceItemName = s.PriceItemName });
            prizes.Remove(s);
            entries.RemoveAll(x => x.Id == op.Id);
          }
          
        }
      }

      List<Output> univOutput = new List<Output>();
      univOutput.AddRange(output);
      univOutput.AddRange(output2);
      univOutput.AddRange(output4);
      univOutput.AddRange(output6);

      foreach (var item in univOutput)
      {
        Console.WriteLine($"id= { item.Id }, Name= {item.Name}, Email= {item.Email}, Date_Participated= {item.Date_Participated}, Date_Unlocker={item.Date_Unlocked} ");
      }
      Console.ReadLine();

    }
  }
}
